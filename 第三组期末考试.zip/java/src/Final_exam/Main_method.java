package Final_exam;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Main_method {
	private JFrame frame;
	private JPasswordField passwordField;
	private JTextField textField;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main_method window = new Main_method();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Main_method() {
		initialize();
	}

	public void judge() {

	}

	private void initialize() {
		frame = new JFrame();
		frame.setSize(300, 300);
		IRW.center(frame);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		Label label_2 = new Label("����������ϵͳ");
		label_2.setBounds(110, 50, 100, 40);
		label_2.setBackground(Color.yellow);
		frame.getContentPane().add(label_2);
		JButton btnNewButton = new JButton("��¼");
		btnNewButton.setBounds(120, 200, 75, 25);
		btnNewButton.setBackground(Color.orange);
		btnNewButton.addActionListener(new ActionListener() {
			int i = 3;

			public void actionPerformed(ActionEvent arg0) {
				String usr = textField.getText();
				String pwd = passwordField.getText();
				while (i != 0) {
					if (usr.equals("root") & pwd.equals("root")) {
						JOptionPane.showMessageDialog(null, "��¼�ɹ�");
						new MainFrame().setVisible(true);
						break;
					} else {
						JOptionPane.showMessageDialog(null, "�˻��������������������");
						break;
					}
				}

				
			}
		});
		frame.getContentPane().add(btnNewButton);
		Label label = new Label("����Ա�˺�:");
		label.setBounds(45, 110, 70, 23);
		Label label_1 = new Label("����:");
		label_1.setBounds(80, 160, 34, 23);
		
		textField = new JTextField();
		textField.setBounds(115, 110, 97, 21);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(115, 160, 97, 21);
		frame.getContentPane().add(textField);
		frame.getContentPane().add(passwordField);
		frame.getContentPane().add(label);
		frame.getContentPane().add(label_1);

	}

}

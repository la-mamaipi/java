package Final_exam;

public class MainFrame extends AbstractMainFrame{
	public void showAdminDialog() {
		new AdminDialogController(this,true).setVisible(true);
	}

}

package Final_exam;
import java.util.ArrayList;
public class Book {
	public static ArrayList<CargoItem> data=new ArrayList<CargoItem>();
	static {
		data.add(new CargoItem("000001","���μ�",20,"100"));
		data.add(new CargoItem("000002","��¥��",20,"100"));
		data.add(new CargoItem("000003","��������",20,"100"));
		data.add(new CargoItem("000004","ˮ䰴�",20,"100"));
	}
}

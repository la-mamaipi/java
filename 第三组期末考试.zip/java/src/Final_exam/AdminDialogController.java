package Final_exam;
import java.awt.Frame;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.table.*;

public class AdminDialogController extends AbstractAdminDialog{
	private AdminService adminService=new AdminService();
	public AdminDialogController() {
		super();
	}
	public AdminDialogController(Frame owner,boolean modal) {
		super(owner,modal);
		queryCargoItem();
	}
	@Override
	public void queryCargoItem() {
		String [] thead={"�鼮���","�鼮����","�鼮�۸�"};
		ArrayList<CargoItem> dataList=adminService.queryCargoItem();
		String[][] tbody=list2Array(dataList);
		TableModel dataModel=new DefaultTableModel(tbody,thead);
		table.setModel(dataModel);
	}

	private String[][] list2Array(ArrayList<CargoItem> list) {
		String[][] tbody=new String[list.size()][4];
		for(int i=0;i<list.size();i++) {
			CargoItem cargoItem=list.get(i);
			tbody[i][0]=cargoItem.getNumber();
			tbody[i][1]=cargoItem.getName();
			tbody[i][2]=cargoItem.getPrice()+"";
			tbody[i][3]=cargoItem.getUnit();
		}
		return tbody;
	}
	public void addCargoItem() {
		String addNumber=addNumberText.getText();
		String addName=addNameText.getText();
		String addPrice=addPriceText.getText();
		String addUnit=addUnitText.getText();
		boolean addSuccess=adminService.addCargoItem(addNumber, addName, addPrice, addUnit);
		if(addSuccess) {
			queryCargoItem();
		}else {
			JOptionPane.showMessageDialog(this, "�鼮��Ų����ظ�����������!");
		}
	}

	public void updateCargoItem() {
		String updateNumber=updateNumberText.getText();
		String updateName=updateNameText.getText();
		String updatePrice=updatePriceText.getText();
		String updateUnit=updateUnitText.getText();
		boolean updateSuccess=adminService.updateCargoItem(updateNumber,updateName, updatePrice, updateUnit);
		if(updateSuccess) {
			queryCargoItem();
		}else {
			JOptionPane.showMessageDialog(this, "û�������ŵ��鼮,����������!");
		}
	}

	public void delCargoItem() {
		String delNumber=delNumberText.getText();
		boolean delSuccess=adminService.delCargoItem(delNumber);
		if(delSuccess) {
			queryCargoItem();
		}else {
			JOptionPane.showMessageDialog(this, "û�������ŵ��鼮,����������!");
		}
	}
	
}

package Final_exam;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public abstract class AbstractMainFrame extends JFrame {
	
	private JLabel titleLabel = new JLabel(new ImageIcon("timg.jpg"));
	private JButton btn = new JButton("�������");

	public AbstractMainFrame() {	
		this.init();
		this.addComponent();
		this.addListener();
	}

	private void init() {
		this.setTitle("������껶ӭ��");
		this.setSize(600, 500);
		
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		IRW.center(this);
		IRW.setTitleImage(this, "title.png");
	}

	private void addComponent() {
		this.add(this.titleLabel, BorderLayout.NORTH);
		JPanel btnPanel = new JPanel();
		btnPanel.setLayout(null);
		this.add(btnPanel);
		btn.setBounds(240, 20, 120, 50);
		btnPanel.add(btn);
	}

	private void addListener() {
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showAdminDialog();
			}
		});
	}

	public abstract void showAdminDialog();
}

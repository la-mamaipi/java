package Final_exam;
import java.util.ArrayList;
public class AdminDao {
	public ArrayList<CargoItem> queryAllData(){
		return Book.data;
	}
	public void addCargoItem(CargoItem fruitItem) {
		Book.data.add(fruitItem);
	}
	
    public void delCargoItem(String delNumber) {
    	for(int i=0;i<Book.data.size();i++) {
    		CargoItem thisFruitItem=Book.data.get(i);
    		if(thisFruitItem.getNumber().equals(delNumber)) {
    			Book.data.remove(i);
    		}
    	}
    }
}

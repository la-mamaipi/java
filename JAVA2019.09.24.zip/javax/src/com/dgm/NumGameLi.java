package com.dgm;

public class NumGameLi {
     private int[] arr;
     public NumGameLi(int[] arr){
     this.arr=arr;
     }
     public  String buildOutArray(){
 	 StringBuffer res=new StringBuffer();
 	 for(int i=0;i<arr.length;i++){
 	 res.append(arr[i]);
 	 if(i !=arr.length-1){
 		res.append(" ,");
     }
     }
     return res.toString();
     }
     public static int max(int[] arr){
     int max =arr[0];
     for(int i=0;i<arr.length;i++){
     max=Math.max(max, arr[i]);
     }
      return max;
}
     public  int max(){
    	 int max =arr[0];
    	 for(int i=0;i<arr.length;i++){
    	 max=Math.max(max, arr[i]);
     }
     return max;
}
}
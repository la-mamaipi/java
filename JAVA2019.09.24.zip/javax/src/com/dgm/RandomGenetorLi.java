package com.dgm;

public class RandomGenetorLi {
	public static int [] generateArray(int length){
	int[]arr=new int[length];
	for(int i=0;i<arr.length;i++){
	arr[i]=(int)(100*Math.random());
	
 }
	return arr;
 }
 }
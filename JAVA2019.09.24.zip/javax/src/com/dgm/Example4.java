package com.dgm;

public class Example4 {
  public static void main(String[] args) {
	System.out.println();
	int [] arr=RandomGenetorLi.generateArray(10);
	NumGameLi numGame=new NumGameLi(arr);
	System.out.println(numGame.buildOutArray());
	System.out.println("���ֵ�ǣ�"+numGame.max(arr));
   }
  /*
    public static int [] generateArray(int length){
	int[]arr=new int[length];
	for(int i=0;i<arr.length;i++){
	arr[i]=(int)(100*Math.random());
   }
        return arr;
   }
       public static String buildOutArray(int[] arr){
	   StringBuffer res=new StringBuffer();
	   for(int i=0;i<arr.length;i++){
	   res.append(arr[i]);
	   if(i !=arr.length-1){
		res.append(" ,");
    }
    }
     return res.toString();
     }
     public static int max(int[] arr){
    	 int max =arr[0];
    	 for(int i=0;i<arr.length;i++){
    	 max=Math.max(max, arr[i]);
     }
     return max;
     }
     */
     }
